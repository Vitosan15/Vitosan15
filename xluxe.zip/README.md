# Magic Store - Ropa Oversize

Este es el código de la tienda web **Magic Store (XLUXE)**.  
Puedes publicarlo fácilmente en GitHub Pages.

## 🚀 Cómo publicarlo

1. Sube estos archivos a un nuevo repositorio en GitHub.
2. Ve a **Settings > Pages**.
3. En "Source", selecciona la rama `main` y la carpeta `/root`.
4. Guarda los cambios y obtendrás el link de tu tienda online.

